<?php 
/**
 * Template Name: Contact Page
 * The template for displaying the contact page.
 *
 * @package Therosessom
 */

get_header();

        get_template_part( 'template-parts/intro/intro' );

get_footer();